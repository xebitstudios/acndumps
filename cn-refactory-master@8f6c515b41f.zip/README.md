This Consist of following projects.

consumer: this is a legacy app consisting EJBs, Web App (JSPs and Servlets) and EAR.

It consist of a simple hotel consumer which has first name, last name, level (gold, silver, Platinum etc.) and year to date number of nights.
Consumer is stored in  PostgreSQL database. EJBs are used to store and retrieve consumers from database.

Web app consist of JSPs form to fill in details for consumer and save it to database using EJB. It also JSP and servlets to find and display all consumers.

consumer-mercury-rest: this is a PROXY service. It has been developed using Mercury lambda functions to create and find consumers using Legacy app.
