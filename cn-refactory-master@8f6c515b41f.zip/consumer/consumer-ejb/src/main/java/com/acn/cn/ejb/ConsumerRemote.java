package com.acn.cn.ejb;

import com.acn.cn.model.Consumer;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface ConsumerRemote {
    List<Consumer> findAllConsumer();
    Consumer createConsumer(Consumer consumer);
}