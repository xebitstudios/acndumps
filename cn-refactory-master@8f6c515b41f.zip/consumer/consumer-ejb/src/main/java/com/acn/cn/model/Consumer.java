package com.acn.cn.model;


import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CONSUMER")
@NamedQuery(name = "Consumer.findAll", query = "SELECT c FROM Consumer c")
public class Consumer implements Serializable {

    private static final long serialVersionUID = 3072475211055736282L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CONSUMER_ID")
    private int consumerId;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "LEVEL")
    private String level;
    @Column(name = "YEAR_TO_DATE_NIGHTS")
    private String yearToDatedNights;
    
	public Consumer() {
		super();
	}
	public int getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(int consumerId) {
		this.consumerId = consumerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getYearToDatedNights() {
		return yearToDatedNights;
	}
	public void setYearToDatedNights(String yearToDatedNights) {
		this.yearToDatedNights = yearToDatedNights;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
 }

