package com.acn.cn.ejb;

import com.acn.cn.model.Consumer;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class ConsumerSessionBean implements ConsumerLocal, ConsumerRemote{

    @PersistenceContext(unitName = "consumer-ejb")
    private EntityManager em;

    @Override
    public List<Consumer> findAllConsumer() {
        return em.createNamedQuery("Consumer.findAll")
                .getResultList();
    }

    @Override
    public Consumer createConsumer(Consumer consumer) {
    	em.persist(consumer);
        return consumer;
    }
}
