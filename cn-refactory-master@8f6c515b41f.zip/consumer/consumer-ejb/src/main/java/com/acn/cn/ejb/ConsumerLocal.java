package com.acn.cn.ejb;

import com.acn.cn.model.Consumer;

import javax.ejb.Local;
import java.util.List;

@Local
public interface ConsumerLocal {
    List<Consumer> findAllConsumer();
    Consumer createConsumer(Consumer consumer);
}