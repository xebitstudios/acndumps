package com.acn.cn.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.acn.cn.ejb.ConsumerLocal;
import com.acn.cn.model.Consumer;

@WebServlet(
		description = "Consumer", 
		urlPatterns = { 
				"/consumer", 
				"/cn"
		})

public class GetConsumers extends HttpServlet{
	
    @EJB
    private ConsumerLocal consumerBean;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Consumer> consumers = consumerBean.findAllConsumer();

        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head>\n"
        		+ "<style>\n"
        		+ "table, th, td {\n"
        		+ "  border: 1px solid black;\n"
        		+ "}\n"
        		+ "</style>\n"
        		+ "</head> ");
        
        out.println("<body>");
        
        out.println("<h1>List of All Consumers</h1>");
        
        out.print("<table style=\"width:50%\">\n"
    			+ "  <tr>\n"
    			+ "    <th>Customer ID</th>\n"
    			+ "    <th>First Name</th>\n"
    			+ "    <th>Last Name</th> \n"
    			+ "    <th>Total Nights</th>\n"
    			+ "    <th>Level</th>\n"
    			+ "  </tr>");
        
        for (Consumer consumer : consumers) {
        	
        	
        	out.print("  <tr>\n"
        			+ "    <td> " + consumer.getConsumerId() + " </td>\n"
        			+ "    <td> " + consumer.getFirstName() + " </td>\n"
        			+ "    <td> " + consumer.getLastName() + " </td>\n"
        			+ "    <td> " + consumer.getYearToDatedNights() + " </td>\n"
        			+ "    <td> " + consumer.getLevel() + " </td>\n"
        			+ "  </tr> ");
        }
        
        out.println("</body>");
        out.println("</html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
