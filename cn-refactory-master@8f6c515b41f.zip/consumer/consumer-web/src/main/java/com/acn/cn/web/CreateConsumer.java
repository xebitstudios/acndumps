package com.acn.cn.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.acn.cn.ejb.ConsumerLocal;
import com.acn.cn.model.Consumer;

/**
 * Servlet implementation class CreateConsumer
 */
@WebServlet(
		description = "CreateConsumer", 
		urlPatterns = { 
				"/createconsumer", 
				"/cc"
		})
public class CreateConsumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    @EJB
    private ConsumerLocal consumerBean;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateConsumer() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
        
        String fistName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String level = request.getParameter("level");
        String yearToDateNights = request.getParameter("yearToDateNights");
        
        Consumer consumer = new Consumer();
        consumer.setFirstName(fistName);
        consumer.setLastName(lastName);
        consumer.setLevel(level);
        consumer.setYearToDatedNights(yearToDateNights);
        
        consumerBean.createConsumer(consumer);
        
       
        response.setContentType("text/html;charset=UTF-8");
        
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Consumer Has been Created.</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("First Name: " +fistName);
            out.println("Last Name: " +lastName);
            out.println("</body>");
            out.println("</html>");
            
        } finally {
           out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
         execute(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        execute(request, response);
    }

}
