package com.acn.ce.consumer.util;

import com.acn.cn.ejb.ConsumerRemote;
import lombok.extern.slf4j.Slf4j;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

/**
 * Utility class to locate remote reference to EJB.
 *
 * @author Syed Moid
 */
@Slf4j
public class EjbLookUp {

    public static ConsumerRemote consumerEjb = null;

    private static Context context() throws NamingException {
        Properties jndiProps = new Properties();
        jndiProps.put("java.naming.factory.initial", "org.jboss.naming.remote.client.InitialContextFactory");
        jndiProps.put("jboss.naming.client.ejb.context", true);
        jndiProps.put("java.naming.provider.url", "http-remoting://localhost:9091");
        return new InitialContext(jndiProps);
    }

    public static ConsumerRemote consumerRemoteInterface() {
        try {
             consumerEjb = (ConsumerRemote) context().lookup(getFullName());
        } catch (NamingException ne) {
            log.error("Naming Exception Occurred: " + ne);
        }
        return consumerEjb;
    }

    private static String getFullName() {
        return "ejb:consumer-ear-0.0.1-SNAPSHOT/consumer-web-0.0.1-SNAPSHOT/ConsumerSessionBean!com.acn.cn.ejb.ConsumerRemote";
    }
}
