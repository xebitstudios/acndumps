package com.acn.ce.consumer.handler;

import com.acn.ce.consumer.util.EjbLookUp;
import com.acn.cn.ejb.ConsumerRemote;
import com.acn.cn.model.Consumer;
import org.platformlambda.core.models.AsyncHttpRequest;
import org.platformlambda.core.models.LambdaFunction;

import java.util.HashMap;
import java.util.Map;

/**
 * Lambda Function to create consumer. It used EJB to create consumer.
 *
 * @author Syed Moid
 */
public class CreateConsumer implements LambdaFunction {
    ConsumerRemote ejb = EjbLookUp.consumerRemoteInterface();

    @Override
    public Object handleEvent(Map<String, String> headers, Object body, int instance) {
        AsyncHttpRequest req = new AsyncHttpRequest(body);
        HashMap reqMap = (HashMap) req.getBody();

        Consumer consumer = new Consumer();
        consumer.setFirstName((String) reqMap.get("first_name"));
        consumer.setLastName((String) reqMap.get("last_name"));
        consumer.setLevel((String) reqMap.get("level"));
        consumer.setYearToDatedNights((String) reqMap.get("year_to_dated_nights"));

        consumer = ejb.createConsumer(consumer);

        return consumer;
    }
}
