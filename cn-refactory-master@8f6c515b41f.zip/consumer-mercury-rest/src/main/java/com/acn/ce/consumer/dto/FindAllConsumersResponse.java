package com.acn.ce.consumer.dto;

import lombok.*;

import java.util.List;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor

/**
 * Response object. This is a container class containing list of consumers,
 * which is returned to REST Client.
 *
 * @author Syed Moid
 */
public class FindAllConsumersResponse {
    private List<ConsumerDto> consumers;
}
