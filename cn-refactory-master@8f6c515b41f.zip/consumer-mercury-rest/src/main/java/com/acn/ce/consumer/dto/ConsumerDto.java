package com.acn.ce.consumer.dto;

import lombok.*;
import org.springframework.beans.factory.annotation.Value;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor

/**
 * Model class to represent consumer. This is passed as request object by REST Client.
 *
 * @author Syed Moid
 */
public class ConsumerDto {
    private Integer consumerId;
    private String firstName;
    private String lastName;
    private String level;
    private String yearToDatedNights;
}
