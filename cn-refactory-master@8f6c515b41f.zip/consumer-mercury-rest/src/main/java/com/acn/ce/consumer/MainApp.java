package com.acn.ce.consumer;

import com.acn.ce.consumer.handler.CreateConsumer;
import com.acn.ce.consumer.handler.FindAllConsumers;
import org.platformlambda.core.annotations.MainApplication;
import org.platformlambda.core.models.EntryPoint;
import org.platformlambda.core.system.Platform;
import org.platformlambda.core.system.ServerPersonality;
import org.platformlambda.rest.RestServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main class for REST Automation client, which servers as entry point.
 *
 * @author Syed Moid
 */
@MainApplication
public class MainApp implements EntryPoint {
    private static final Logger log = LoggerFactory.getLogger(MainApp.class);

    public static void main(String[] args) {
        RestServer.main(args);
    }

    @Override
    public void start(String[] args) throws Exception {

        // Set personality to WEB - this must be done in the beginning
        ServerPersonality.getInstance().setType(ServerPersonality.Type.WEB);

        Platform platform = Platform.getInstance();
        platform.register("consumer.create", new CreateConsumer(), 5);
        platform.register("consumer.find.all", new FindAllConsumers(), 5);
        /*
         * In distributed mode, cloud services are started automatically when you connect to cloud.
         * In standalone mode, you can start cloud services programmatically using:
         *
         * platform.startCloudServices();
         */
        // connect to the network event streams so it can automatically discover other services
        platform.connectToCloud();

        log.info("Application started");
    }
}
