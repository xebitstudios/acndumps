package com.acn.ce.consumer.handler;

import com.acn.ce.consumer.dto.ConsumerDto;
import com.acn.ce.consumer.dto.FindAllConsumersResponse;
import com.acn.ce.consumer.util.EjbLookUp;
import com.acn.cn.ejb.ConsumerRemote;
import org.platformlambda.core.models.LambdaFunction;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Lambda Function to find all consumers in PostgreSQL. It used EJB to find all consumers.
 *
 * @author Syed Moid
 */
public class FindAllConsumers implements LambdaFunction {
    ConsumerRemote consumerRemote = EjbLookUp.consumerRemoteInterface();

    @Override
    public Object handleEvent(Map<String, String> headers, Object body, int instance) {
        FindAllConsumersResponse response = new FindAllConsumersResponse();

        List<ConsumerDto> consumerDtos = consumerRemote.findAllConsumer().stream().map(
                consumer ->
                        new ConsumerDto(consumer.getConsumerId(),
                                consumer.getFirstName(),
                                consumer.getLastName(),
                                consumer.getLevel(),
                                consumer.getYearToDatedNights())
        ).collect(Collectors.toList());
        response.setConsumers(consumerDtos);
        return response;
    }
}
